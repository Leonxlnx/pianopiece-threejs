# Daybreak desktop film renderer

Frozen renderer: render.py. Native 1920 × 1080 output at timeline times n/24.

This is an offline rendered export of the published scene, not a browser screen recording. It uses the actual Three.js procedural key transforms, skinned character vertices/normals, camera matrices and authored score timing streamed by ../daybreak-video/pose-server.mjs. No frame interpolation or still-image animation is used.

Included: source materials/albedo textures, 419 meshes, eight deformed character meshes, individual piano strings, 480 animated stage dust points, original procedural sky, four score-driven lights, two spot shadow maps, mirrored stage geometry, 4× multisample anti-aliasing, film tone mapping and restrained bloom.

Rendering adaptations: direct-light GGX shader and analytical environment reflections approximate the original Three.js material pipeline; stage reflection uses a half-resolution mirrored camera; source haze cones, canvas plaque and normal-map microdetail are omitted. These adaptations affect appearance, not performance timing or geometry.

Benchmark: ten consecutive native1080p frames at175.2–175.575s averaged1.657s/frame (range1.206–2.055s) with Mesa llvmpipe. Per-frame JSON includes exact timeline time, camera shot, active piano notes, finger contacts and pedal position. Full runtime varies by shot.

Full-film orchestration belongs to ../daybreak-video/render-film.py, which streams RGB into H.264 chunks. Root will mux the original verified AAC master and save finished downloads.
