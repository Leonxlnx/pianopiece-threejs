import os,json,time,subprocess,base64,math
from pathlib import Path
import numpy as np
from PIL import Image
import moderngl
ROOT=Path('/workspace/scratch/daybreak-video-gl');SOURCE=Path('/workspace/scratch/daybreak-video')
os.environ['LD_LIBRARY_PATH']=str(SOURCE/'egl-libs/root/usr/lib/x86_64-linux-gnu')
os.environ['__EGL_VENDOR_LIBRARY_FILENAMES']=str(SOURCE/'egl-libs/root/usr/share/glvnd/egl_vendor.d/50_mesa.json')
ctx=moderngl.create_standalone_context(backend='egl',require=330,libegl=str(SOURCE/'egl-libs/root/usr/lib/x86_64-linux-gnu/libEGL.so.1'),libgl='libGL.so.1')
print('RENDERER',ctx.info['GL_RENDERER'],flush=True)
server=subprocess.Popen(['node','pose-server.mjs'],cwd=SOURCE,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
ready=json.loads(server.stdout.readline());d=json.load(open(ready['scene']))
W=int(os.environ.get('WIDTH','1280'));H=W*9//16
vert='''#version 330
in vec3 in_pos;in vec3 in_norm;in vec2 in_uv;uniform mat4 model;uniform mat4 vp;uniform mat4 shadowVP[2];out vec3 world;out vec3 norm;out vec2 uv;out vec4 sh[2];
void main(){vec4 p=model*vec4(in_pos,1.);world=p.xyz;norm=mat3(transpose(inverse(model)))*in_norm;uv=in_uv;gl_Position=vp*p;sh[0]=shadowVP[0]*p;sh[1]=shadowVP[1]*p;}
'''
frag='''#version 330
in vec3 world;in vec3 norm;in vec2 uv;in vec4 sh[2];out vec4 color;
uniform vec3 eye;uniform vec3 base;uniform float rough;uniform float metal;uniform float coat;uniform vec3 emissive;uniform float opacity;uniform float alphaTest;uniform sampler2D tex;uniform bool hasTex;
uniform vec3 lightPos[4];uniform vec3 lightColor[4];uniform vec3 lightDir[4];uniform float lightIntensity[4];uniform vec2 cone[4];uniform sampler2DShadow shadow0;uniform sampler2DShadow shadow1;uniform float lift;uniform bool basic;uniform bool reflectionPass;uniform bool floorMirror;uniform sampler2D reflectionTex;uniform mat4 reflectionVP;
const float PI=3.14159265;
vec3 sky(vec3 p){float h=smoothstep(-.08,.65,p.y);vec3 low=mix(vec3(.21,.27,.31),vec3(.80,.59,.41),lift);vec3 high=mix(vec3(.075,.13,.19),vec3(.26,.37,.43),lift);vec3 col=mix(low,high,h);float glow=pow(max(0.,dot(p,normalize(vec3(-.4,.26,-1.)))),12.);return col+vec3(.58,.31,.14)*glow*(.18+lift*.5);}
float shadowFactor(int i,vec3 N,vec3 L){vec3 p=sh[i].xyz/sh[i].w*.5+.5;if(p.z>1.||p.x<0.||p.x>1.||p.y<0.||p.y>1.)return 1.;float bias=max(.0005*(1.-dot(N,L)),.00012);float sum=0.;for(int a=-1;a<=1;a++)for(int b=-1;b<=1;b++){vec3 q=vec3(p.xy+vec2(a,b)*.00165,p.z-bias);sum+=i==0?texture(shadow0,q):texture(shadow1,q);}return sum/9.;}
vec3 fresnel(float c,vec3 f){return f+(1.-f)*pow(clamp(1.-c,0.,1.),5.);}
void main(){if(reflectionPass&&world.y<.008)discard;vec4 tx=hasTex?texture(tex,uv):vec4(1);if(tx.a*opacity<max(alphaTest,.08))discard;vec3 albedo=base*pow(tx.rgb,vec3(2.2));vec3 N=normalize(norm);if(!gl_FrontFacing)N=-N;vec3 V=normalize(eye-world);float NV=max(dot(N,V),.001);vec3 F0=mix(vec3(.04-.016*rough),albedo,metal);float r=max(rough,.065);float a=r*r;float a2=a*a;
vec3 env=sky(N)*.70;vec3 result=albedo*(1.-metal)*env*.74;vec3 R=reflect(-V,N);vec3 envspec=sky(R);float softbox=pow(max(dot(R,normalize(vec3(-.2,1.,.35))),0.),mix(250.,3.,rough));envspec+=vec3(1.4,1.2,.95)*softbox*(1.-rough*.8);result+=envspec*(F0+(max(vec3(1.-rough),F0)-F0)*pow(1.-NV,5.))*(1.-rough*.52);result+=coat*.13*envspec*pow(1.-NV,2.);
for(int i=0;i<4;i++){vec3 to=lightPos[i]-world;float dist=length(to);vec3 L=to/dist;float NL=max(dot(N,L),0.);vec3 H=normalize(V+L);float NH=max(dot(N,H),0.);float VH=max(dot(V,H),0.);float D=a2/(PI*pow(NH*NH*(a2-1.)+1.,2.));float k=pow(r+1.,2.)/8.;float G=(NV/(NV*(1.-k)+k))*(NL/(NL*(1.-k)+k));vec3 F=fresnel(VH,F0);vec3 spec=D*G*F/max(4.*NV*NL,.001);float spot=i<3?smoothstep(cone[i].x,cone[i].y,dot(-L,lightDir[i])):1.;float shade=(i==0||i==2)?shadowFactor(i==0?0:1,N,L):1.;vec3 radiance=lightColor[i]*lightIntensity[i]*.70/pow(max(dist,.5),i==0?1.8:1.7)*spot;result+=((1.-F)*(1.-metal)*albedo/PI+spec)*radiance*NL*shade;}
result+=emissive;if(basic)result=emissive;if(floorMirror&&!reflectionPass&&world.y>-.01){vec4 rh=reflectionVP*vec4(world,1.);vec2 ru=rh.xy/rh.w*.5+.5;vec3 rc=texture(reflectionTex,ru).rgb;result=mix(result,rc*.38,.35);}float fog=1.-exp(-length(eye-world)*.009);result=mix(result,sky(normalize(world-eye))*.65,fog);color=vec4(result,tx.a*opacity);}
'''
prog=ctx.program(vertex_shader=vert,fragment_shader=frag)
shadowprog=ctx.program(vertex_shader='''#version 330
in vec3 in_pos;in vec2 in_uv;uniform mat4 model;uniform mat4 vp;out vec2 uv;void main(){uv=in_uv;gl_Position=vp*model*vec4(in_pos,1.);}''',fragment_shader='''#version 330
in vec2 uv;uniform sampler2D tex;uniform bool hasTex;uniform float alphaTest;void main(){if(hasTex&&texture(tex,uv).a<max(alphaTest,.08))discard;}''')
quadvert='''#version 330
in vec2 p;out vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0,1);}'''
bgprog=ctx.program(vertex_shader=quadvert,fragment_shader='''#version 330
in vec2 uv;out vec4 color;uniform mat4 invVP;uniform vec3 eye;uniform float lift;
void main(){vec4 h=invVP*vec4(uv*2.-1.,1.,1.);vec3 p=normalize(h.xyz/h.w-eye);float y=smoothstep(-.08,.65,p.y);vec3 low=mix(vec3(.21,.27,.31),vec3(.80,.59,.41),lift);vec3 high=mix(vec3(.075,.13,.19),vec3(.26,.37,.43),lift);vec3 col=mix(low,high,y);float glow=pow(max(0.,dot(p,normalize(vec3(-.4,.26,-1.)))),12.);col+=vec3(.58,.31,.14)*glow*(.18+lift*.5);color=vec4(col,1.);}''')
postprog=ctx.program(vertex_shader=quadvert,fragment_shader='''#version 330
in vec2 uv;out vec4 color;uniform sampler2D tex;uniform vec2 pixel;
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){vec3 c=texture(tex,uv).rgb;vec3 bloom=vec3(0);for(int x=-2;x<=2;x++)for(int y=-2;y<=2;y++){vec3 t=texture(tex,uv+vec2(x,y)*pixel*3.).rgb;bloom+=max(t-1.,0.)/25.;}c+=bloom*.085;c=pow(aces(c*.85),vec3(1./2.2));float v=1.-.12*pow(length((uv-.5)*vec2(1.2,1.)),2.);color=vec4(c*v,1.);}''')
quad=ctx.buffer(np.array([-1,-1,1,-1,-1,1,1,1],dtype='f4').tobytes());bgvao=ctx.simple_vertex_array(bgprog,quad,'p');postvao=ctx.simple_vertex_array(postprog,quad,'p')
def mat4(a):return np.array(a,dtype='f4').reshape(4,4).T
def norm(v):return v/(np.linalg.norm(v)+1e-20)
def perspective(fov,asp,near=.03,far=180):
 f=1/math.tan(math.radians(fov)/2);return np.array([[f/asp,0,0,0],[0,f,0,0],[0,0,(far+near)/(near-far),2*far*near/(near-far)],[0,0,-1,0]],dtype='f4')
def lookat(eye,target):
 f=norm(np.array(target)-eye);r=norm(np.cross(f,[0,1,0]));u=np.cross(r,f);m=np.eye(4,dtype='f4');m[:3,:3]=[r,u,-f];m[:3,3]=-m[:3,:3]@eye;return m
textures={}
def texture(path):
 if path not in textures:
  im=Image.open(path).convert('RGBA') if path else Image.new('RGBA',(1,1),(255,255,255,255));tx=ctx.texture(im.size,4,im.tobytes());tx.build_mipmaps();tx.filter=(moderngl.LINEAR_MIPMAP_LINEAR,moderngl.LINEAR);tx.anisotropy=4.;textures[path]=tx
 return textures[path]
for m in d['materials']:m['_tex']=texture(m['map'])
def normals(v,idx):
 n=np.zeros_like(v);tris=idx.reshape(-1,3);tn=np.cross(v[tris[:,1]]-v[tris[:,0]],v[tris[:,2]]-v[tris[:,0]]);np.add.at(n,tris[:,0],tn);np.add.at(n,tris[:,1],tn);np.add.at(n,tris[:,2],tn);return n/np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-20)
meshes=[]
for m in d['meshes']:
 v=np.array(m['vertices'],dtype='f4').reshape(-1,3);idx=np.array(m['indices'],dtype='i4');n=np.array(m['normals'],dtype='f4').reshape(-1,3) if m.get('normals') else normals(v,idx);uv=np.array(m['uvs'],dtype='f4').reshape(-1,2) if m['uvs'] else np.zeros((len(v),2),'f4');inter=np.hstack([v,n,uv]).astype('f4');vb=ctx.buffer(inter.tobytes());ib=ctx.buffer(idx.tobytes());vao=ctx.vertex_array(prog,[(vb,'3f 3f 2f','in_pos','in_norm','in_uv')],ib);sv=ctx.vertex_array(shadowprog,[(vb,'3f 12x 2f','in_pos','in_uv')],ib);meshes.append({'source':m,'data':inter,'vb':vb,'vao':vao,'sv':sv,'matrix':mat4(m['matrix']),'idx':idx})
lineprog=ctx.program(vertex_shader="""#version 330
in vec3 in_pos;in vec3 in_color;out vec3 c;uniform mat4 vp;uniform mat4 model;void main(){c=in_color;gl_Position=vp*model*vec4(in_pos,1.);}""",fragment_shader="""#version 330
in vec3 c;out vec4 color;uniform float opacity;void main(){color=vec4(c*.68,opacity);}""")
lineobjects=[]
for m in d.get('lines',[]):
 v=np.array(m['vertices'],dtype='f4').reshape(-1,3);c=np.array(m['colors'],dtype='f4').reshape(-1,3) if m['colors'] else np.tile(m['color'],(len(v),1));buf=ctx.buffer(np.hstack([v,c]).astype('f4').tobytes());va=ctx.simple_vertex_array(lineprog,buf,'in_pos','in_color');lineobjects.append((va,mat4(m['matrix']),m['opacity']))
dustprog=ctx.program(vertex_shader="""#version 330
in vec3 in_pos;in float in_size;in float in_seed;uniform float t;uniform mat4 view;uniform mat4 projection;out float alpha;void main(){vec3 p=in_pos;p.x+=sin(t*.085+in_seed)*.18;p.y+=sin(t*.06+in_seed*2.)*.14;p.z+=cos(t*.035+in_seed)*.2;vec4 mv=view*vec4(p,1.);gl_Position=projection*mv;gl_PointSize=clamp(in_size*17./(-mv.z),.7,3.5);alpha=.18+.35*pow(sin(in_seed+t*.11),2.);}""",fragment_shader="""#version 330
in float alpha;out vec4 color;uniform float lift;void main(){float d=length(gl_PointCoord-.5);float a=smoothstep(.5,.05,d)*alpha;color=vec4(mix(vec3(.68,.79,.9),vec3(1.,.8,.52),lift),a*.55);}""")
dustobjects=[]
for m in d.get('points',[]):
 v=np.array(m['vertices'],dtype='f4').reshape(-1,3);buf=ctx.buffer(np.column_stack([v,m['sizes'],m['seeds']]).astype('f4').tobytes());dustobjects.append(ctx.simple_vertex_array(dustprog,buf,'in_pos','in_size','in_seed'))
shadows=[];shadowVP=[]
for i in [0,2]:
 l=d['lights'][i];vp=perspective(math.degrees(l['angle']*2),1,.1,23)@lookat(np.array(l['position']),l['target']);shadowVP.append(vp);depth=ctx.depth_texture((1536,1536));depth.compare_func='<=';depth.filter=(moderngl.LINEAR,moderngl.LINEAR);depth.repeat_x=False;depth.repeat_y=False;shadows.append((depth,ctx.framebuffer(depth_attachment=depth)))
color=ctx.texture((W,H),4,dtype='f2');resolved=ctx.framebuffer([color]);msColor=ctx.renderbuffer((W,H),4,samples=4,dtype='f2');depth=ctx.depth_renderbuffer((W,H),samples=4);fbo=ctx.framebuffer([msColor],depth);refl=ctx.texture((W//2,H//2),4,dtype='f2');refl.filter=(moderngl.LINEAR,moderngl.LINEAR);reflfbo=ctx.framebuffer([refl],ctx.depth_renderbuffer((W//2,H//2)));dummy=ctx.texture((1,1),4,bytes([0,0,0,255]));outtex=ctx.texture((W,H),4);outfbo=ctx.framebuffer([outtex]);prog['tex']=0;prog['shadow0']=1;prog['shadow1']=2;prog['reflectionTex']=3;postprog['tex']=0;postprog['pixel']=(1/W,1/H)
prog['shadowVP'].write(np.stack(shadowVP).transpose(0,2,1).astype('f4').tobytes())
prog['lightPos'].write(np.array([l['position'] for l in d['lights']],dtype='f4').tobytes());prog['lightColor'].write(np.array([l['color'] for l in d['lights']],dtype='f4').tobytes());prog['lightDir'].write(np.array([norm(np.array(l['target'])-l['position']) if l['target'] else [0,0,0] for l in d['lights'][:3]],dtype='f4').tobytes());prog['cone'].write(np.array([[math.cos(l.get('angle',1)),math.cos(l.get('angle',1)*(1-l.get('penumbra',0)))] for l in d['lights'][:3]],dtype='f4').tobytes())
def draw_mesh(ob,pr,shadow=False):
 pr['model'].write(ob['matrix'].T.astype('f4').tobytes());m=ob['source'];groups=m['groups'] if len(m['materials'])>1 and m['groups'] else [{'start':0,'count':len(ob['idx']),'materialIndex':0}]
 for g in groups:
  mat=d['materials'][m['materials'][g['materialIndex'] if len(m['materials'])>1 else 0]];mat['_tex'].use(0);pr['hasTex']=bool(mat['map']);pr['alphaTest']=mat['alphaTest']
  if not shadow:
   pr['basic']=mat.get('basic',False);pr['floorMirror']=ob is meshes[0]
   for key,mkey in [('base','color'),('rough','roughness'),('metal','metalness'),('coat','clearcoat'),('emissive','emissive'),('opacity','alpha')]:pr[key].value=tuple(np.array(mat[mkey])*mat.get('emissiveIntensity',1)) if mkey=='emissive' else tuple(mat[mkey]) if isinstance(mat[mkey],list) else mat[mkey]
  (ob['sv'] if shadow else ob['vao']).render(moderngl.TRIANGLES,vertices=g['count'],first=g['start'])
def frame(t):
 before=time.perf_counter();server.stdin.write(str(t)+'\n');server.stdin.flush();s=json.loads(server.stdout.readline());
 for ob,st in zip(meshes,s['meshes']):
  ob['matrix']=mat4(st['matrix'])
  if 'vertices' in st:
   v=np.frombuffer(base64.b64decode(st['vertices']),dtype='<f4').reshape(-1,3);ob['data'][:,:3]=v;ob['data'][:,3:6]=np.frombuffer(base64.b64decode(st['normals']),dtype='<f4').reshape(-1,3) if 'normals' in st else normals(v,ob['idx']);ob['vb'].write(ob['data'].tobytes())
 for m,e in zip(d['materials'],s['emissive']):m['emissive']=e
 updated=time.perf_counter();ctx.enable(moderngl.DEPTH_TEST);ctx.disable(moderngl.CULL_FACE|moderngl.BLEND)
 for j,(tx,sfbo) in enumerate(shadows):
  sfbo.use();ctx.viewport=(0,0,1536,1536);sfbo.clear(depth=1.);shadowprog['vp'].write(shadowVP[j].T.tobytes())
  for ob in meshes:draw_mesh(ob,shadowprog,True)
 shadowed=time.perf_counter();cm=mat4(s['camera']['matrix']);eye=cm[:3,3];vp=perspective(s['camera']['fov'],s['camera']['aspect'])@np.linalg.inv(cm);x=np.clip((s['energy']-.22)/.7,0,1);lift=float(x*x*(3-2*x));reflect=np.diag([1,-1,1,1]).astype('f4');rcm=reflect@cm;rvp=perspective(s['camera']['fov'],s['camera']['aspect'])@np.linalg.inv(rcm);prog['reflectionVP'].write(rvp.T.astype('f4').tobytes());prog['lightIntensity'].write(np.array(s['lights'],dtype='f4').tobytes());shadows[0][0].use(1);shadows[1][0].use(2)
 for reflectionPass,target,cvp,ceye,ww,hh in [(True,reflfbo,rvp,rcm[:3,3],W//2,H//2),(False,fbo,vp,eye,W,H)]:
  target.use();ctx.viewport=(0,0,ww,hh);target.clear(.1,.15,.2,1,depth=1.);ctx.disable(moderngl.DEPTH_TEST);bgprog['invVP'].write(np.linalg.inv(cvp).T.astype('f4').tobytes());bgprog['eye'].value=tuple(ceye);bgprog['lift']=lift;bgvao.render(moderngl.TRIANGLE_STRIP);ctx.enable(moderngl.DEPTH_TEST);prog['reflectionPass']=reflectionPass;(dummy if reflectionPass else refl).use(3)
  prog['vp'].write(cvp.T.astype('f4').tobytes());prog['eye'].value=tuple(ceye);prog['lift']=lift
  for ob in meshes:
   if reflectionPass and ob['matrix'][1,3]<0:continue
   draw_mesh(ob,prog)
  ctx.enable(moderngl.BLEND);ctx.blend_func=(moderngl.SRC_ALPHA,moderngl.ONE_MINUS_SRC_ALPHA);lineprog['vp'].write(cvp.T.astype('f4').tobytes());ctx.line_width=1.
  for va,model,opacity in lineobjects:
   lineprog['model'].write(model.T.astype('f4').tobytes());lineprog['opacity']=opacity;va.render(moderngl.LINES)
  if not reflectionPass:
   ctx.enable(moderngl.PROGRAM_POINT_SIZE);ctx.blend_func=(moderngl.SRC_ALPHA,moderngl.ONE);ctx.depth_mask=False;dustprog['t']=t;dustprog['lift']=lift;dustprog['view'].write(np.linalg.inv(cm).T.astype('f4').tobytes());dustprog['projection'].write(perspective(s['camera']['fov'],s['camera']['aspect']).T.astype('f4').tobytes())
   for va in dustobjects:va.render(moderngl.POINTS)
   ctx.depth_mask=True
  ctx.disable(moderngl.BLEND)
 ctx.copy_framebuffer(resolved,fbo)
 outfbo.use();ctx.disable(moderngl.DEPTH_TEST);color.use(0);postvao.render(moderngl.TRIANGLE_STRIP);raw=outfbo.read(components=3,alignment=1);done=time.perf_counter();return raw,{'time':t,'shot':s['shot'],'update':updated-before,'shadows':shadowed-updated,'render':done-shadowed,'total':done-before,'pedal':s.get('pedal'),'contacts':s.get('contacts'),'activeNotes':s.get('activeNotes')}
if __name__=='__main__':
 result=[]
 for i,t in enumerate([float(x) for x in os.environ.get('TIMES','0,138,184,184.041667').split(',')]):
  raw,row=frame(t);Image.frombytes('RGB',(W,H),raw).transpose(Image.Transpose.FLIP_TOP_BOTTOM).save(ROOT/f'gl-{W}-{i}.jpg',quality=95);result.append(row);print(json.dumps(row),flush=True)
 (ROOT/f'benchmark-{W}.json').write_text(json.dumps(result,indent=2));server.terminate()
