# Approved visual correction: bounded audit handoff

The rounded-thumb sample at105.625s was visually accepted by root. Original Site/main-render inputs remain unchanged. All corrected inputs in this folder are frozen.

Correction: keep original thumb distal joint center, orientation and fingertip target; solve the proximal joint toward the rest metacarpal opposition direction. Minimal-swing orientation is applied only to the first two thumb bones. The score, keypresses, camera direction, hand planning and all non-thumb bones are unchanged. No skin weights or textures change.

## Pose-only validation

Audited every frame in [672,960), [1824,2112), [2496,3024), [3648,3936) at24fps:1,392poses. No rendered frames were generated during this audit.

- No nonfinite transforms.
- Active note lists identical.
- Maximum skeletal contact error0.000324mm, identical maximum to original.
- Distal thumb center differs by at most0.0000229mm; orientation by0.0000197degrees.
- Other bone positions identical; normalized-quaternion comparison differs by at most0.00000382degrees.
- Maximum distal skin candidate displacement0.000288mm.
-993 held-thumb skin/key samples; none missing; signed gaps−1.023 to−0.068mm; none outside±3mm.
- Continuously held thumb angular changes remain below0.00000342degrees.

Material continuity bound: corrected local thumb angular maximum81.67degrees/frame versus original93.35. At existing unheld transitions, LeftHandThumb2 world rotation reaches109.60degrees atframe918 (38.25s) and122.41degrees atframe2761 (115.041667s). No thumb note remains held through either event. An additional free right-thumb local-angle maximum81.67degrees occurs atframe3859 (160.791667s), while its world change is40.14degrees. Review these points in encoded replacement footage; they are not contact failures. This audit does not establish subjective animation quality at every frame.

Full machine-readable data: audit-1392.json. Audit implementation: audit-ranges.mjs. The audit normalizes quaternions before angle comparison to avoid reporting false differences for equal nonunit floating-point representations.

## Frozen input hashes

- render.py:10c5444f617f0b1414fb1c61c07a75cf4f9fc9ad287995aebeec4ddeaa4b365c
- pose-server.mjs:179c9fc0fc8c87250caa98aab6f840db79f17ac0b3c3cf757573705d985b71b3
- compiled/pianist.mjs:841ae55c66e98ac9ab2aeb678fd0548ddb2a54de1e2dbd1032e1948323e2dc35
- pianist.patch:2e1a364c6318f4d1211550b2ba5580c1e08d9b8babb171c9b9d84392822cfe1f

Renderer import path: /dev/shm/daybreak-wedge-qa/contact-preserving/render.py

pianist.patch targets the Site's app/performance/pianist.ts for possible later integration by root. This task has not modified, committed or deployed the Site. The corrected module is an isolated offline-export dependency, not a browser recording.
