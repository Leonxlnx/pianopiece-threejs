"""Recreate the exact reviewed compiled correction from the verified base module.
This stores only the small accepted delta, not the compiled Site module.
Usage: python rebuild-approved-compiled.py BASE_COMPILED FRESH_OUTPUT
"""
from pathlib import Path
import hashlib,sys
BASE_SHA256='541e78c6ff367979c5fc35c2f4b43ed455b1165df40708acbfba349a16fc4971'
OUTPUT_SHA256='841ae55c66e98ac9ab2aeb678fd0548ddb2a54de1e2dbd1032e1948323e2dc35'
EDITS=[(22252, 22252, 'if (fi === 0) {\n                    const restDirection = finger.bones[1].position.clone().applyQuaternion(finger.bones[0].getWorldQuaternion(new THREE.Quaternion())).normalize();\n                    shape.pip.copy(joint(base, shape.dip, finger.lengths[0], finger.lengths[1], base.clone().add(restDirection)));\n                }\n                '), (22479, 22479, 'let q;\n                    if (fi === 0 && j < 2) {\n                        '), (22484, 22484, ' bone = finger.bones[j], child = finger.bones[j + 1];\n                        const restWorld = bone.getWorldQuaternion(new THREE.Quaternion());\n                        const restDirection = child.position.clone().applyQuaternion(restWorld).normalize();\n                        q = new THREE.Quaternion().setFromUnitVectors(restDirection, dir).multiply(restWorld);\n                    } else {\n                       '), (22650, 22650, '\n                    }')]
source=Path(sys.argv[1]);target=Path(sys.argv[2])
if target.exists():raise SystemExit('Refusing to overwrite an existing output; choose a fresh isolated path.')
raw=source.read_bytes()
if hashlib.sha256(raw).hexdigest()!=BASE_SHA256:raise SystemExit('Base compiled module does not match the frozen source.')
text=raw.decode('utf-8')
for first,last,replacement in reversed(EDITS):text=text[:first]+replacement+text[last:]
result=text.encode('utf-8')
if hashlib.sha256(result).hexdigest()!=OUTPUT_SHA256:raise SystemExit('Rebuilt correction hash mismatch.')
target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result)
print(OUTPUT_SHA256+'  '+str(target))
