"""Inspect the actual encoded deliverable, including complete decode and AAC identity."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

movie = Path(sys.argv[1])
source_audio = Path('/workspace/scratch/daybreak-assets/master/daybreak-master.m4a')

def run(args):
    return subprocess.check_output(args)

probe = json.loads(run([
    'ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(movie)
]))
video = next(s for s in probe['streams'] if s['codec_type'] == 'video')
audio = next(s for s in probe['streams'] if s['codec_type'] == 'audio')
frame_probe = json.loads(run([
    'ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_frames',
    '-show_entries', 'frame=best_effort_timestamp_time', '-of', 'json', str(movie)
]))
pts = [float(f['best_effort_timestamp_time']) for f in frame_probe['frames']]
cadence_error = max(abs(t - i / 24) for i, t in enumerate(pts))

def audio_packets(path):
    return hashlib.sha256(run([
        'ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:a:0',
        '-c:a', 'copy', '-f', 'adts', '-'
    ])).hexdigest()

decoded = subprocess.run([
    'ffmpeg', '-v', 'error', '-i', str(movie), '-f', 'null', '-'
], capture_output=True, text=True)
report = {
    'file': str(movie),
    'bytes': movie.stat().st_size,
    'sha256': hashlib.sha256(movie.read_bytes()).hexdigest(),
    'video': {k: video.get(k) for k in (
        'codec_name', 'profile', 'width', 'height', 'pix_fmt', 'r_frame_rate',
        'avg_frame_rate', 'start_time', 'duration', 'nb_frames'
    )},
    'audio': {k: audio.get(k) for k in (
        'codec_name', 'profile', 'sample_rate', 'channels', 'start_time', 'duration'
    )},
    'aac_packets_identical_to_master': audio_packets(movie) == audio_packets(source_audio),
    'decoded_video_frames': len(pts),
    'maximum_frame_timestamp_error_seconds': cadence_error,
    'all_video_frames_in_exact_24fps_sequence': cadence_error <= 0.000001,
    'full_decode_exit_code': decoded.returncode,
    'full_decode_errors': decoded.stderr.strip(),
    'listening_performed': False,
    'browser_screen_recording': False,
}
report_path = movie.with_suffix('.qa.json')
report_path.write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
if decoded.returncode or decoded.stderr.strip():
    raise SystemExit('The full decode reported a problem.')
if cadence_error > 0.000001 or len(pts) != 5497:
    raise SystemExit('The encoded frame timeline does not match the full score.')
