"""Package completed, real frame renders with the original mastered soundtrack."""
import json
import subprocess
import sys
from pathlib import Path

film = Path(sys.argv[1])
destination = Path(sys.argv[2])
destination.mkdir(parents=True, exist_ok=True)
master = Path('/workspace/scratch/daybreak-assets/master')
site = 'https://daybreak-piano-film.lexn8.chatgpt.site'
comment = (
    'Offline rendered export of DAYBREAK, an original composition and virtual piano performance. '
    'Piano recordings: Salamander Grand Piano v3 by Alexander Holm, CC BY 3.0 '
    '(https://creativecommons.org/licenses/by/3.0/). Original score, performance, mix and mastering. '
    'Sample source: https://github.com/sfzinstruments/SalamanderGrandPiano. '
    'Additional CC0 ensemble/percussion and character credits: ' + site + '/assets/credits.txt. '
    'Interactive performance: ' + site + '.'
)

def encode(args):
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', *args], check=True)

priority = [film / f'chunk-{i:03d}.mp4' for i in (9, 10, 11)]
if (not (destination / 'Daybreak-social-cut.mp4').exists()
        and all(p.exists() and p.with_suffix('.json').exists() for p in priority)):
    concat = destination / 'social-concat.txt'
    concat.write_text(''.join("file '" + str(p).replace("'", "'\\''") + "'\n" for p in priority))
    duration = 691 / 24
    encode([
        '-f', 'concat', '-safe', '0', '-i', str(concat),
        '-ss', str(4148 / 24), '-i', str(master / 'daybreak-master.wav'),
        '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '256k',
        '-af', f'afade=t=in:st=0:d=0.005,afade=t=out:st={duration - .55}:d=0.55',
        '-t', str(duration), '-movflags', '+faststart',
        '-metadata', 'title=DAYBREAK | The lift', '-metadata', 'comment=' + comment,
        str(destination / 'Daybreak-social-cut.mp4'),
    ])
    print('SOCIAL_EXPORT_READY', flush=True)

if (film / 'completion.json').exists():
    report = json.loads((film / 'completion.json').read_text())
    assert report['complete'] and report['frames'] == 5497
    encode([
        '-i', str(film / 'daybreak-video-only.mp4'),
        '-i', str(master / 'daybreak-master.m4a'),
        '-map', '0:v:0', '-map', '1:a:0', '-c', 'copy', '-movflags', '+faststart',
        '-metadata', 'title=DAYBREAK | Full desktop performance',
        '-metadata', 'comment=' + comment,
        str(destination / 'Daybreak-full-desktop.mp4'),
    ])
    print('FULL_EXPORT_READY', flush=True)
