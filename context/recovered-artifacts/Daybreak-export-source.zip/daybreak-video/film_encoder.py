"""Stream actual rendered RGB frames; encode without a full PNG sequence on disk."""
from pathlib import Path
import json, math, subprocess, hashlib, os

class FrameEncoder:
 def __init__(self, output, width=1920, height=1080, fps=24, crf=18):
  self.output=Path(output);self.output.parent.mkdir(parents=True,exist_ok=True)
  self.width,self.height,self.fps=width,height,fps;self.frames=0
  self.partial=self.output.with_name(self.output.stem+'-video.partial.mp4')
  self.log_path=self.output.with_suffix('.encode.log');self.log=self.log_path.open('wb')
  self.command=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{width}x{height}','-framerate',str(fps),'-i','pipe:0','-an','-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709','-c:v','libx264','-preset','fast','-crf',str(crf),'-pix_fmt','yuv420p','-r',str(fps),'-g',str(fps*2),'-keyint_min',str(fps*2),'-sc_threshold','0','-threads','2','-movflags','+frag_keyframe+empty_moov+default_base_moof','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',str(self.partial)]
  self.process=subprocess.Popen(self.command,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=self.log)
 def write(self,rgb):
  if hasattr(rgb,'shape'):
   import numpy as np
   if rgb.shape!=(self.height,self.width,3) or rgb.dtype!=np.uint8:raise ValueError('Expected height×width×3 uint8 RGB frame')
   rgb=np.ascontiguousarray(rgb).tobytes()
  if len(rgb)!=self.width*self.height*3:raise ValueError('Unexpected RGB frame byte length')
  self.process.stdin.write(rgb);self.frames+=1
 def finish_video(self,duration):
  expected=math.ceil(duration*self.fps-1e-8)
  if self.frames!=expected:raise ValueError(f'Expected {expected} actual frames, received {self.frames}')
  self.process.stdin.close();code=self.process.wait();self.log.close()
  if code:raise RuntimeError(f'Frame encoder failed ({code}): {self.log_path}')
  return self.partial
 def finalize(self,audio_path,duration,title='Daybreak — original piano performance',audio_start=0,copy_audio=False):
  expected=math.ceil(duration*self.fps-1e-8)
  if self.frames!=expected:raise ValueError(f'Expected {expected} actual frames, received {self.frames}')
  self.finish_video(duration)
  args=['ffmpeg','-hide_banner','-loglevel','warning','-y','-i',str(self.partial)]
  if audio_start:args+=['-ss',str(audio_start)]
  args+=['-i',str(audio_path),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','copy' if copy_audio else 'aac',* ([] if copy_audio else ['-b:a','256k','-ar','44100']),'-t',f'{duration:.9f}','-movflags','+faststart','-metadata','title='+title,'-metadata','comment=Offline rendered export using the Daybreak source scene, exact performance poses, authored cameras and original score. This file is not a browser screen recording.',str(self.output)]
  result=subprocess.run(args,capture_output=True,text=True)
  if result.returncode:raise RuntimeError(result.stderr)
  probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames,duration,start_time,sample_rate,channels:format=duration,size','-of','json',str(self.output)]))
  metadata={'output':str(self.output),'sha256':hashlib.file_digest(self.output.open('rb'),'sha256').hexdigest(),'width':self.width,'height':self.height,'fps':self.fps,'rendered_frames':self.frames,'expected_frames':expected,'timeline_duration':duration,'audio_source':str(audio_path),'audio_start':audio_start,'audio_sha256':hashlib.file_digest(open(audio_path,'rb'),'sha256').hexdigest(),'screen_recording':False,'frame_interpolation':False,'probe':probe}
  self.output.with_suffix('.json').write_text(json.dumps(metadata,indent=2))
  self.partial.unlink();return metadata
