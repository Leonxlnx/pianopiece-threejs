"""Prepare or apply exact-frame, packet-preserving Daybreak video corrections.
Default is preparation only. --execute requires completed approved patch movies.
Never renders, changes frozen inputs, overwrites the base movie, or touches audio.
"""
from pathlib import Path
from fractions import Fraction
import argparse,json,subprocess,hashlib,math,shlex
FPS=24;TOTAL=5497;RANGES=[(672,960),(1824,2112),(2496,3024),(3648,3936)];LIMIT=224*1024*1024

def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def probe(p):
 return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_packets','-show_data_hash','sha256','-show_entries','stream=codec_name,profile,level,width,height,pix_fmt,r_frame_rate,time_base,nb_frames,duration,start_time,extradata_hash:packet=pts,dts,duration,size,flags,data_hash','-of','json',str(p)]))
def frame_hashes(p):
 out=subprocess.check_output(['ffmpeg','-v','error','-threads','1','-i',str(p),'-map','0:v:0','-an','-fps_mode','passthrough','-f','framemd5','-'],text=True)
 rows=[]
 for line in out.splitlines():
  if not line or line.startswith('#'):continue
  parts=[x.strip() for x in line.split(',')];rows.append({'pts':int(parts[2]),'md5':parts[-1]})
 return rows

a=argparse.ArgumentParser();a.add_argument('--base',default='/dev/shm/daybreak-film-1080p');a.add_argument('--patches',required=True,help='JSON list of approved {start,end,video,manifest} patch movies');a.add_argument('--output',default='/dev/shm/daybreak-corrected-splice');a.add_argument('--execute',action='store_true');a.add_argument('--ranges',help='Reviewed ordered JSON list of [start_frame,end_frame] pairs');args=a.parse_args()
BASE=Path(args.base);OUT=Path(args.output);OUT.mkdir(parents=True,exist_ok=True)
base_manifest=json.loads((BASE/'manifest.json').read_text());boundaries=base_manifest['segment_boundaries'];assert boundaries[0]==0 and boundaries[-1]==TOTAL
if args.ranges:RANGES=json.loads(Path(args.ranges).read_text())
assert isinstance(RANGES,list) and RANGES and all(isinstance(v,(list,tuple)) and len(v)==2 and all(type(n) is int for n in v) and 0<=v[0]<v[1]<=TOTAL for v in RANGES),'Invalid reviewed frame ranges'
assert all(a[1]<=b[0] for a,b in zip(RANGES,RANGES[1:])),'Reviewed ranges must be ordered and nonoverlapping'
valid_cuts=set(boundaries)
for a,b in zip(boundaries,boundaries[1:]):valid_cuts.update(range(a,b,48))
assert all(a in valid_cuts and b in valid_cuts for a,b in RANGES),'Reviewed ranges must follow actual base GOP boundaries'
patches=json.loads(Path(args.patches).read_text());assert [(p['start'],p['end']) for p in patches]==[tuple(v) for v in RANGES]
intervals=[];cursor=0
for patch in patches:
 if cursor<patch['start']:intervals.append({'kind':'base','start':cursor,'end':patch['start']})
 intervals.append({'kind':'patch',**patch});cursor=patch['end']
if cursor<TOTAL:intervals.append({'kind':'base','start':cursor,'end':TOTAL})
segments=[]
for interval in intervals:
 if interval['kind']=='patch':
  segments.append({'kind':'patch','start':interval['start'],'end':interval['end'],'source':interval['video'],'source_first':0,'patch_manifest':interval['manifest']});continue
 for i,(first,end) in enumerate(zip(boundaries,boundaries[1:])):
  begin=max(first,interval['start']);stop=min(end,interval['end'])
  if begin<stop:segments.append({'kind':'base','start':begin,'end':stop,'source':str(BASE/f'chunk-{i:03d}.mp4'),'source_first':begin-first,'base_chunk':i})
assert all(s['end']==segments[i+1]['start'] for i,s in enumerate(segments[:-1])) and sum(s['end']-s['start'] for s in segments)==TOTAL
plan={'kind':'Exact-frame video correction; audio untouched','fps':FPS,'final_frames':TOTAL,'corrected_ranges':RANGES,'ranges_config_sha256':digest(args.ranges) if args.ranges else None,'corrected_frame_count':sum(b-a for a,b in RANGES),'segments':segments,'executed':False,'base_manifest_sha256':digest(BASE/'manifest.json'),'staging_limit_bytes':LIMIT,'method':'input keyframe seek + explicit packet/frame count + concat auto_convert=0; packet and decoded-frame checks required'}
(OUT/'splice-plan.json').write_text(json.dumps(plan,indent=2))
if not args.execute:print(json.dumps({'prepared':True,'plan':str(OUT/'splice-plan.json'),'segments':len(segments),'frames':TOTAL,'corrected_frames':plan['corrected_frame_count']}));raise SystemExit(0)
final=OUT/'daybreak-corrected-video-only.mp4'
if final.exists():raise RuntimeError('Refusing to overwrite existing corrected output; use a fresh staging folder.')
cache={};selected_packets=[];expected_frames=[];files=[];evidence=[];cuts=[];codec=None;estimate_cuts=0;estimate_final=0
for i,s in enumerate(segments):
 source=Path(s['source']);assert source.exists(),source
 if str(source) not in cache:
  d=probe(source);stream=d['streams'][0];assert stream['codec_name']=='h264' and stream['width']==1920 and stream['height']==1080 and stream['r_frame_rate']=='24/1' and stream['pix_fmt']=='yuv420p'
  if codec is None:codec={k:stream[k] for k in ['codec_name','profile','level','width','height','pix_fmt','extradata_hash']}
  else:assert {k:stream[k] for k in codec}==codec,'Codec/extradata differ: packet copy is unsafe; use the documented reencode fallback.'
  cache[str(source)]={'probe':d,'sha256':digest(source),'frames':None}
 info=cache[str(source)];d=info['probe'];stream=d['streams'][0];tb=Fraction(stream['time_base']);ticks=Fraction(1,FPS)/tb;assert ticks.denominator==1;ticks=int(ticks)
 count=s['end']-s['start'];first=s['source_first'];last=first+count;assert 0<=first<last<=int(stream['nb_frames'])
 chosen=[p for p in d['packets'] if first*ticks<=p['pts']<last*ticks]
 assert len(chosen)==count and 'K' in chosen[0]['flags'],'Segment does not begin on a closed GOP keyframe'
 assert sorted(p['pts'] for p in chosen)==list(range(first*ticks,last*ticks,ticks))
 if s['kind']=='base':
  m=json.loads((BASE/f'chunk-{s["base_chunk"]:03d}.json').read_text());assert info['sha256']==m['sha256']
 else:
  m=json.loads(Path(s['patch_manifest']).read_text());assert m['approved'] is True and m['start_frame']==s['start'] and m['end_frame']==s['end'] and m['fps']==FPS and m['frames']==count and m['video_sha256']==info['sha256']
 estimate_final+=sum(int(p['size']) for p in chosen)
 needs_cut=first!=0 or count!=int(stream['nb_frames'])
 if needs_cut:estimate_cuts+=sum(int(p['size']) for p in chosen)+131072
 selected_packets.extend(p['data_hash'] for p in chosen)
 evidence.append({'segment':i,**s,'frames':count,'source_sha256':info['sha256'],'packet_count':len(chosen),'first_packet_sha256':chosen[0]['data_hash'],'last_packet_sha256':chosen[-1]['data_hash']})
# Conservative container/index allowance. Patch movies and the base are read-only
# inputs outside the staging reservation; only cuts and final output count here.
assert estimate_final+estimate_cuts+4*1024*1024<LIMIT,'The packet-preserving staging estimate exceeds224MiB. Use fallback or a separately approved reservation.'
for i,s in enumerate(segments):
 source=Path(s['source']);info=cache[str(source)];count=s['end']-s['start'];first=s['source_first'];stream=info['probe']['streams'][0];ticks=int(Fraction(1,FPS)/Fraction(stream['time_base']))
 if first==0 and count==int(stream['nb_frames']):path=source
 else:
  path=OUT/f'cut-{i:02d}.mp4';subprocess.run(['ffmpeg','-v','error','-y','-ss',f'{first/FPS:.12f}','-i',str(source),'-frames:v',str(count),'-map','0:v:0','-an','-c:v','copy','-movflags','+faststart',str(path)],check=True);cuts.append(path)
  cut=probe(path);expected=[p['data_hash'] for p in info['probe']['packets'] if first*ticks<=p['pts']<(first+count)*ticks]
  assert [p['data_hash'] for p in cut['packets']]==expected and int(cut['streams'][0]['nb_frames'])==count,'Cut packet verification failed'
 files.append(path)
 if info['frames'] is None:info['frames']=frame_hashes(source)
 expected_frames.extend(v['md5'] for v in info['frames'][first:first+count])
listing=OUT/'splice-concat.txt';listing.write_text(''.join("file '"+str(p).replace("'","'\\''")+"'\n" for p in files))
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-auto_convert','0','-i',str(listing),'-map','0:v:0','-an','-c:v','copy','-movflags','+faststart',str(final)],check=True)
d=probe(final);stream=d['streams'][0];ticks=int(Fraction(1,FPS)/Fraction(stream['time_base']))
assert int(stream['nb_frames'])==TOTAL and len(d['packets'])==TOTAL and float(stream['start_time'])==0
assert [p['data_hash'] for p in d['packets']]==selected_packets,'A packet changed or moved in decode order'
assert sorted(p['pts'] for p in d['packets'])==list(range(0,TOTAL*ticks,ticks)),'Missing/duplicate presentation timestamps'
assert all(b['dts']-a['dts']==ticks for a,b in zip(d['packets'],d['packets'][1:])),'Decode timestamps have a gap or overlap'
assert all(p['duration']==ticks for p in d['packets']),'Unexpected packet duration'
actual=frame_hashes(final);assert len(actual)==TOTAL and [r['pts'] for r in actual]==list(range(TOTAL)) and [r['md5'] for r in actual]==expected_frames,'Decoded frames differ or timing/order changed'
assert final.stat().st_size<LIMIT
report={**plan,'executed':True,'passed':True,'output':str(final),'output_sha256':digest(final),'output_bytes':final.stat().st_size,'codec':codec,'segments':evidence,'packet_payloads_preserved':True,'decoded_frames_identical_to_selected_sources':True,'presentation_frames':TOTAL,'audio_modified':False,'temporary_cut_bytes':sum(p.stat().st_size for p in cuts)}
(OUT/'splice-verification.json').write_text(json.dumps(report,indent=2));print(json.dumps({'passed':True,'output':str(final),'frames':TOTAL,'bytes':final.stat().st_size,'untouched_packets_preserved':True,'audio_modified':False}))
