"""Prepare/run isolated, explicitly approved native-frame correction ranges.
No changes to base render inputs or output. Default is prepare only.
"""
from pathlib import Path
import argparse,os,sys,json,hashlib,importlib.util,subprocess,time,re,ast
import numpy as np
from PIL import Image
ROOT=Path('/workspace/scratch/daybreak-video');sys.path.insert(0,str(ROOT))
from film_encoder import FrameEncoder
RANGES=[(672,960),(1824,2112),(2496,3024),(3648,3936)];FPS=24

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=argparse.ArgumentParser();p.add_argument('--module',required=True);p.add_argument('--source-root',required=True);p.add_argument('--approval',required=True);p.add_argument('--out',default='/dev/shm/daybreak-corrections');p.add_argument('--execute',action='store_true');p.add_argument('--ranges',help='Reviewed ordered JSON list of [start_frame,end_frame] pairs');args=p.parse_args()
if args.ranges:RANGES=json.loads(Path(args.ranges).read_text())
assert isinstance(RANGES,list) and RANGES and all(isinstance(v,(list,tuple)) and len(v)==2 and all(type(n) is int for n in v) and 0<=v[0]<v[1]<=5497 for v in RANGES),'Invalid reviewed frame ranges'
assert all(a[1]<=b[0] for a,b in zip(RANGES,RANGES[1:])),'Reviewed ranges must be ordered and nonoverlapping'
base_manifest=json.loads((ROOT/'film-1080p/manifest.json').read_text());bounds=base_manifest['segment_boundaries'];valid_cuts=set(bounds)
for a,b in zip(bounds,bounds[1:]):valid_cuts.update(range(a,b,48))
assert all(a in valid_cuts and b in valid_cuts for a,b in RANGES),'Reviewed ranges must follow actual base GOP boundaries'
MODULE=Path(args.module).resolve();SOURCE=Path(args.source_root).resolve();OUT=Path(args.out);assert SOURCE!=ROOT.resolve(),'A corrected pose server must be an isolated clone';OUT.mkdir(parents=True,exist_ok=True)
files=[MODULE,SOURCE/'pose-server.mjs',*sorted((SOURCE/'compiled').glob('*.mjs')),SOURCE/'public/assets/score.json',SOURCE/'public/assets/pianist.glb',ROOT/'film_encoder.py']
if args.ranges:files.append(Path(args.ranges).resolve())
runtime_vendor=SOURCE/'egl-libs/root/usr/share/glvnd/egl_vendor.d/50_mesa.json'
if runtime_vendor.is_file():files.append(runtime_vendor)
approval=json.loads(Path(args.approval).read_text())
additional=approval.get('additional_source_sha256',{})
assert isinstance(additional,dict),'additional_source_sha256 must be a SOURCE-relative path→SHA256 map'
core_paths={f.absolute() for f in files};additional_paths={}
for name,expected in additional.items():
 assert isinstance(name,str),'Additional source paths must be strings'
 rel=Path(name)
 assert not rel.is_absolute() and '..' not in rel.parts,'Additional source paths must stay inside isolated SOURCE'
 path=(SOURCE/rel).absolute()
 assert path.is_file(),f'Additional source missing: {name}'
 assert isinstance(expected,str) and re.fullmatch('[0-9a-fA-F]{64}',expected),'Expected an exact SHA256 for '+name
 actual=sha(path);assert actual==expected.lower(),'Additional source hash mismatch: '+name
 additional_paths[path]=actual
# Require declarations for literal local imports/data loads, including imports
# made recursively by declared helpers. Computed/dynamic data paths must also be
# explicitly listed by the reviewer; the map is not limited to code files.
code_suffixes={'.py','.js','.mjs','.cjs'}
data_suffixes=code_suffixes|{'.json','.glsl','.npy','.npz','.bin','.csv','.glb'}
known=core_paths|set(additional_paths);queue=list(known);scanned=set();discovered={}
while queue:
 source=queue.pop()
 if source in scanned or source.suffix not in code_suffixes:continue
 scanned.add(source);text=source.read_text();candidates=[]
 if source.suffix in {'.js','.mjs','.cjs'}:
  for literal in re.findall(r"(?:\bfrom\s*|\bimport\s*\(?\s*|\brequire\s*\(\s*)['\"](\.[^'\"]+)['\"]",text):candidates.append(source.parent/literal)
  for literal in re.findall(r"\bnew\s+URL\s*\(\s*['\"](\.[^'\"]+)['\"]\s*,\s*import\.meta\.url",text):candidates.append(source.parent/literal)
  for args_text in re.findall(r'\b(?:readFileSync|readFile)\s*\(([^;\n]+)',text):
   for literal in re.findall(r"['\"]([^'\"]+)['\"]",args_text):
    if Path(literal).suffix in data_suffixes:candidates.extend([SOURCE/literal,source.parent/literal])
 else:
  tree=ast.parse(text)
  for node in ast.walk(tree):
   names=([a.name for a in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else [])
   for name in names:candidates.extend([source.parent/(name.replace('.','/')+'.py'),SOURCE/(name.replace('.','/')+'.py')])
  for literal in re.findall(r"SOURCE\s*/\s*['\"]([^'\"]+)['\"]",text):
   if Path(literal).suffix in data_suffixes and Path(literal).name!='scene.json':candidates.append(SOURCE/literal)
 for candidate in candidates:
  candidate=Path(os.path.abspath(candidate))
  if not candidate.is_file():continue
  # Runtime package imports are outside the isolated source tree. Every local
  # correction dependency must either be a core asset or be explicitly declared.
  if not candidate.is_relative_to(SOURCE):
   assert candidate in core_paths,'Local import escapes isolated SOURCE: '+str(candidate)
   continue
  if candidate not in known:raise AssertionError('Undeclared local correction dependency: '+str(candidate.relative_to(SOURCE)))
  discovered[str(candidate)]=str(source);queue.append(candidate)
files=sorted(known,key=str);hashes={str(f):sha(f) for f in files}
# Recheck declarations after discovery so a concurrent source change cannot be
# accepted between validation and recording the execution manifest.
assert all(hashes[str(path)]==expected for path,expected in additional_paths.items()),'Additional source changed during preparation'

plan={'ranges':[{'start_frame':a,'end_frame':b,'frames':b-a,'start_seconds':a/FPS} for a,b in RANGES],'ranges_config_sha256':sha(args.ranges) if args.ranges else None,'fps':FPS,'width':1920,'height':1080,'source_sha256':hashes,'additional_source_sha256':additional,'discovered_local_dependencies':discovered,'base_inputs_modified':False,'audio_modified':False,'executed':False}
(OUT/'correction-render-plan.json').write_text(json.dumps(plan,indent=2))
if not args.execute:print(json.dumps({'prepared':True,'plan':str(OUT/'correction-render-plan.json')}));raise SystemExit(0)
assert approval.get('approved') is True and approval['renderer_sha256']==hashes[str(MODULE)] and approval['pose_server_sha256']==hashes[str(SOURCE/'pose-server.mjs')],'Approval does not match exact isolated sources'
# The cloned renderer controls its own isolated pose-server root. Runtime EGL
# paths must be supplied in the launch environment before Python starts.
os.environ['WIDTH']='1920';spec=importlib.util.spec_from_file_location('corrected_renderer',MODULE);renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
assert renderer.W==1920 and renderer.H==1080 and renderer.SOURCE.resolve()==SOURCE
patches=[]
try:
 for first,last in RANGES:
  assert all(sha(path)==expected for path,expected in hashes.items()),'Approved source changed before correction range'
  count=last-first;stem=f'range-{first}-{last}';video=OUT/(stem+'.mp4');metadata=OUT/(stem+'-approved.json')
  if video.exists() and metadata.exists():
   m=json.loads(metadata.read_text());assert m['video_sha256']==sha(video) and m['source_sha256']==hashes and m['frames']==count
   patches.append({'start':first,'end':last,'video':str(video),'manifest':str(metadata)});continue
  encoder=FrameEncoder(video,1920,1080,FPS,18);started=time.perf_counter()
  with (OUT/(stem+'-frames.jsonl')).open('w') as trace:
   for frame in range(first,last):
    raw,state=renderer.frame(frame/FPS);rgb=np.frombuffer(raw,dtype=np.uint8).reshape(1080,1920,3)[::-1].copy();encoder.write(rgb);state.update(frame=frame,timeline=frame/FPS);trace.write(json.dumps(state)+'\n')
    if frame in [first,first+count//2,last-1]:Image.fromarray(rgb).save(OUT/(stem+f'-{frame}.jpg'),quality=94)
    if (frame-first)%24==0:trace.flush();print(json.dumps({'range':[first,last],'frame':frame,'time':frame/FPS,'elapsed_s':time.perf_counter()-started}),flush=True)
  partial=encoder.finish_video(count/FPS);subprocess.run(['ffmpeg','-v','error','-y','-i',str(partial),'-map','0:v:0','-an','-c:v','copy','-movflags','+faststart',str(video)],check=True);partial.unlink()
  d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_data_hash','sha256','-show_entries','stream=nb_frames,duration,start_time,width,height,r_frame_rate,extradata_hash','-of','json',str(video)]));s=d['streams'][0]
  assert int(s['nb_frames'])==count and float(s['start_time'])==0 and abs(float(s['duration'])-count/FPS)<1e-6
  m={'approved':True,'approval_file_sha256':sha(args.approval),'start_frame':first,'end_frame':last,'fps':FPS,'frames':count,'video_sha256':sha(video),'source_sha256':hashes,'probe':d,'elapsed_s':time.perf_counter()-started,'audio_modified':False};metadata.write_text(json.dumps(m,indent=2));patches.append({'start':first,'end':last,'video':str(video),'manifest':str(metadata)})
  print(json.dumps({'range_complete':[first,last],'frames':count,'output':str(video)}),flush=True)
 (OUT/'approved-patches.json').write_text(json.dumps(patches,indent=2))
 print(json.dumps({'all_corrections_rendered':True,'frames':sum(b-a for a,b in RANGES),'patches':str(OUT/'approved-patches.json')}),flush=True)
finally:renderer.server.terminate()
