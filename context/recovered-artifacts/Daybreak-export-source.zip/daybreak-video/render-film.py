"""Resume-safe native 24fps offline film export, using the selected GL renderer.
No stored raw-frame sequence; each 20-second chunk is encoded immediately.
"""
from pathlib import Path
import os,sys,math,json,hashlib,time,importlib.util,subprocess
import numpy as np
from PIL import Image
from film_encoder import FrameEncoder
ROOT=Path(__file__).resolve().parent
RENDER=Path(os.environ.get('DAYBREAK_RENDER_MODULE','/workspace/scratch/daybreak-video-gl/render.py'))
OUTPUT=Path(os.environ.get('DAYBREAK_VIDEO_OUTPUT',str(ROOT/'film')));OUTPUT.mkdir(parents=True,exist_ok=True)
FPS=24;DURATION=float(os.environ.get('DAYBREAK_VIDEO_DURATION','229.03635'));START=float(os.environ.get('DAYBREAK_VIDEO_START','0'));FRAMES=math.ceil(DURATION*FPS-1e-8);CHUNK=480
priority_text=os.environ.get('DAYBREAK_PRIORITY_FRAMES','4148:4839' if START==0 and FRAMES==5497 else '')
priority=tuple(map(int,priority_text.split(':'))) if priority_text else None
boundaries=set(range(0,FRAMES,CHUNK))|{FRAMES}
if priority:boundaries|={max(0,min(FRAMES,v)) for v in priority}
boundaries=sorted(boundaries);segments=[(i,a,b-a) for i,(a,b) in enumerate(zip(boundaries,boundaries[1:]))]
if priority:segments.sort(key=lambda v:(not(priority[0]<=v[1] and v[1]+v[2]<=priority[1]),v[1]))
sources=[RENDER,ROOT/'film_encoder.py',ROOT/'render-film.py',ROOT/'pose-server.mjs',*sorted((ROOT/'compiled').glob('*.mjs')),ROOT/'public/assets/score.json',ROOT/'public/assets/pianist.glb']
# GLSL may be separate files in a later renderer revision.
sources+=sorted(RENDER.parent.glob('*.glsl'))
source_hashes={str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in sources}
settings={'fps':FPS,'duration':DURATION,'start':START,'frames':FRAMES,'chunk_frames':CHUNK,'segment_boundaries':boundaries,'priority_frames':list(priority) if priority else None,'width':int(os.environ.get('WIDTH','1280')),'crf':18,'source_sha256':source_hashes,'kind':'Offline rendered film, not browser screen recording','frame_interpolation':False}
manifest=OUTPUT/'manifest.json'
if manifest.exists():
 if json.loads(manifest.read_text())!=settings:raise RuntimeError('Existing film chunks use different sources or settings; select a fresh output folder.')
else:manifest.write_text(json.dumps(settings,indent=2))
spec=importlib.util.spec_from_file_location('daybreak_renderer',RENDER);renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
WIDTH,HEIGHT=renderer.W,renderer.H
trace=(OUTPUT/'frames.jsonl').open('a');begun=time.perf_counter();shots=set();complete=[]
try:
 for chunk_index,first,count in segments:
  chunkpath=OUTPUT/f'chunk-{chunk_index:03d}.mp4';meta=chunkpath.with_suffix('.json')
  if chunkpath.exists() and meta.exists():
   saved=json.loads(meta.read_text())
   if saved.get('frames')==count and saved.get('first_frame')==first and saved.get('sha256')==hashlib.file_digest(chunkpath.open('rb'),'sha256').hexdigest():
    complete.append(chunkpath);print(json.dumps({'resume_chunk':chunk_index,'frames_complete':first+count}),flush=True);continue
   raise RuntimeError('Completed chunk integrity mismatch: '+str(chunkpath))
  encoder=FrameEncoder(chunkpath,WIDTH,HEIGHT,FPS,18);chunk_started=time.perf_counter();chunk_shots=set()
  for frame_index in range(first,first+count):
   timeline=START+frame_index/FPS;raw,row=renderer.frame(timeline)
   rgb=np.frombuffer(raw,dtype=np.uint8).reshape(HEIGHT,WIDTH,3)[::-1].copy()
   encoder.write(rgb);row.update(frame=frame_index,timeline=timeline,chunk=chunk_index);trace.write(json.dumps(row)+'\n');chunk_shots.add(row.get('shot',''))
   if row.get('shot','') not in shots:
    shots.add(row.get('shot',''));Image.fromarray(rgb).save(OUTPUT/f'shot-{frame_index:05d}.jpg',quality=92)
   if (frame_index-first)%24==0:
    trace.flush();print(json.dumps({'frame':frame_index,'frames':FRAMES,'timeline':timeline,'shot':row.get('shot'),'render_s':row.get('total'),'elapsed_s':time.perf_counter()-begun}),flush=True)
  partial=encoder.finish_video(count/FPS)
  subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(partial),'-map','0:v:0','-c','copy','-movflags','+faststart',str(chunkpath)],check=True);partial.unlink()
  details={'first_frame':first,'frames':count,'fps':FPS,'width':WIDTH,'height':HEIGHT,'timeline_start':START+first/FPS,'timeline_end':START+(first+count)/FPS,'shots':sorted(chunk_shots),'elapsed_s':time.perf_counter()-chunk_started,'sha256':hashlib.file_digest(chunkpath.open('rb'),'sha256').hexdigest()}
  temp=meta.with_suffix('.tmp');temp.write_text(json.dumps(details,indent=2));temp.replace(meta);complete.append(chunkpath)
  print(json.dumps({'chunk_complete':chunk_index,'frames_complete':first+count,'elapsed_s':details['elapsed_s']}),flush=True)
 complete.sort(key=lambda p:p.name)
 concat=OUTPUT/'concat.txt';concat.write_text(''.join("file '"+str(p).replace("'","'\\''")+"'\n" for p in complete))
 final=OUTPUT/'daybreak-video-only.mp4'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-map','0:v:0','-c','copy','-movflags','+faststart',str(final)],check=True)
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames,duration,start_time:format=duration,size','-of','json',str(final)]))
 assert int(probe['streams'][0]['nb_frames'])==FRAMES
 result={'complete':True,'output':str(final),'frames':FRAMES,'fps':FPS,'timeline_duration':DURATION,'source_start':START,'width':WIDTH,'height':HEIGHT,'chunks':len(complete),'sha256':hashlib.file_digest(final.open('rb'),'sha256').hexdigest(),'probe':probe,'wall_seconds_this_run':time.perf_counter()-begun}
 (OUTPUT/'completion.json').write_text(json.dumps(result,indent=2));print('FILM_COMPLETE '+json.dumps(result),flush=True)
finally:
 trace.close()
 if hasattr(renderer,'server'):
  renderer.server.terminate()
