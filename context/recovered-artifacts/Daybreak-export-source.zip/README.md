# Daybreak offline film export source

This archive preserves only the new offline export tooling. It does not contain the Site repository, its compiled modules, audio, 3D assets, textures, dependency binaries or rendered video.

Interactive original: https://daybreak-piano-film.lexn8.chatgpt.site
Required existing repository checkout: `/workspace/sites/daybreak-performance`.
Checkout HEAD when archived: `4c7fee966d3ae5aa1f77e921ff1e9b0db6e3f318` (the published scene source is also identified by the frozen dependency hashes below).

## What this exports

A native 1920×1080 film at24fps: 5,497 genuinely rendered frames at timeline `n/24`, covering the229.03635-second original score. This is an offline rendered export, not a browser screen recording. The pose server evaluates the actual Three.js key/character animation and authored cameras. No still interpolation is used.

The renderer adds a GGX lighting approximation, analytical environment reflections, two spot shadows, a half-resolution mirrored-camera stage reflection, 4×MSAA and film tone mapping. It includes the source sky, piano strings and480 source dust particles. Original haze cones, the canvas piano plaque and normal-map microdetail are omitted. Exact rendered pixels therefore differ from the browser material pipeline. No claim of listening or deployed browser playback verification is made by this archive.

## Dependencies and layout

Recorded runtime: Linux x86_64, Python3.12, Node24.19.0, FFmpeg6.1.1 with libx264 and AAC, ModernGL5.12.0, glcontext3.0.0, NumPy2.3.5, Pillow12.3.0. Site packages supply Three.js0.183.2 and TypeScript5.9.3. A working Mesa EGL/OpenGL3.3 context is required; the selected run used llvmpipe. Blender is not used.

These scripts intentionally preserve their original absolute paths. On a separate Linux machine, use the same layout or edit paths in a separate working copy before starting a fresh render. Never edit inputs for an existing partial export: the harness refuses to resume mismatched source hashes.

The following are setup commands for a new environment, not commands that were rerun while the delivered film rendered. Install a compatible Node version (at least22.13) first. On an Ubuntu-style system with Python3.12 available:

```bash
sudo apt-get install python3.12-venv ffmpeg libegl1 libegl-mesa0 libgl1 libgl1-mesa-dri
mkdir -p /workspace/scratch
unzip Daybreak-export-source.zip 'daybreak-video/*' 'daybreak-video-gl/*' -d /workspace/scratch
python3.12 -m venv /workspace/scratch/daybreak-export-env
/workspace/scratch/daybreak-export-env/bin/pip install moderngl==5.12.0 glcontext==3.0.0 numpy==2.3.5 Pillow==12.3.0
```

Restore the original Site checkout separately and install its locked dependencies if `node_modules` is absent. The Site's own documented install command is `npm run install:ci`, run inside its checkout. Then prepare the source compiler and the exact EGL paths expected by the frozen renderer:

```bash
cd /workspace/scratch/daybreak-video
mkdir -p compiled
ln -s /workspace/sites/daybreak-performance/node_modules node_modules
ln -s /workspace/sites/daybreak-performance/public public
node compile.cjs
mkdir -p egl-libs/root/usr/lib/x86_64-linux-gnu
mkdir -p egl-libs/root/usr/share/glvnd/egl_vendor.d
ln -s /usr/lib/x86_64-linux-gnu/libEGL.so.1 egl-libs/root/usr/lib/x86_64-linux-gnu/libEGL.so.1
ln -s /usr/lib/x86_64-linux-gnu/libEGL_mesa.so.0 egl-libs/root/usr/lib/x86_64-linux-gnu/libEGL_mesa.so.0
ln -s /usr/share/glvnd/egl_vendor.d/50_mesa.json egl-libs/root/usr/share/glvnd/egl_vendor.d/50_mesa.json
```

The `ln` commands assume fresh directories; keep existing correct links. On other distributions, locate their corresponding EGL library/vendor JSON paths. The original scene, textures and streamed poses are generated automatically from the existing GLB and Site sources when the pose server starts.

## Render, package and verify

Restore the original `daybreak-master.wav` and `daybreak-master.m4a` at `/workspace/scratch/daybreak-assets/master/` separately. They are excluded from this archive. The full export copies the mastered AAC packets; the short social cut encodes a selected passage with short fades from the WAV. The public MP3 alone is not a byte-identical substitute for either master.

Choose an output disk with several GiB free. The selected run used RAM-backed `/dev/shm` after the shared disk filled; RAM storage is temporary and requires a final persistent copy.

```bash
cd /workspace/scratch/daybreak-video
export LD_LIBRARY_PATH=/workspace/scratch/daybreak-video/egl-libs/root/usr/lib/x86_64-linux-gnu
export __EGL_VENDOR_LIBRARY_FILENAMES=/workspace/scratch/daybreak-video/egl-libs/root/usr/share/glvnd/egl_vendor.d/50_mesa.json
WIDTH=1920 DAYBREAK_VIDEO_OUTPUT=/dev/shm/daybreak-film-rebuild /workspace/scratch/daybreak-export-env/bin/python render-film.py
/workspace/scratch/daybreak-export-env/bin/python finish-export.py /dev/shm/daybreak-film-rebuild /dev/shm/daybreak-delivery-rebuild
/workspace/scratch/daybreak-export-env/bin/python verify-export.py /dev/shm/daybreak-delivery-rebuild/Daybreak-full-desktop.mp4
```

The harness renders20-second chunks, prioritizing frames4148–4838 for the28.791667-second social cut. It subsequently concatenates every chunk chronologically. Restart the identical command to resume completed, hash-verified chunks. `finish-export.py` can create the social clip once chunks009–011 are complete; the full movie requires `completion.json`.

`verify-export.py` records the encoded frame timestamps, full decode result and AAC packet identity. It is intended for the full film, not the faded social edit. Inspect its `aac_packets_identical_to_master` result as well as its exit status; the script records that Boolean but does not raise on a false value. Code/signal checks do not constitute critical listening or browser verification.

## Source attribution and dependency notices

The soundtrack is an original composition performed using licensed recordings. Salamander Grand Piano v3 was recorded by Alexander Holm (Yamaha C5), CC BY3.0: https://creativecommons.org/licenses/by/3.0/ . Source: https://github.com/sfzinstruments/SalamanderGrandPiano . The performance changes include velocity selection, pitch resampling, envelopes, original score, mixing, EQ, reverb and mastering.

VSCO2 Community Edition by Versilian Studios/Sam Gossner and Swirly Drums by Karoryfer Samples are CC0. The MakeHuman/MPFB model distributed by met4citizen/TalkingHead is CC0, modified with clothing/material adjustments and procedural performance animation. Complete existing asset attribution and modification details: https://daybreak-piano-film.lexn8.chatgpt.site/assets/credits.txt . Existing Site software notices, including Three.js MIT, are at https://daybreak-piano-film.lexn8.chatgpt.site/assets/software-notices.txt . Preserve those credits when sharing the video; the packaging script embeds the piano attribution and links.

Dependency source/license references (no dependency code or binaries are redistributed here): ModernGL and glcontext, MIT, https://github.com/moderngl/moderngl and https://github.com/moderngl/glcontext ; NumPy, BSD-style core with separately documented bundled licenses, https://github.com/numpy/numpy ; Pillow, MIT-CMU, https://github.com/python-pillow/Pillow ; Mesa, https://www.mesa3d.org/license.html ; FFmpeg, build-dependent LGPL/GPL terms, https://ffmpeg.org/legal.html . The recorded FFmpeg executable was built with GPL components including libx264.

## Selectively corrected final film

Final film delivery uses the original base render plus1,392 corrected frames, not the uncorrected base movie. The published Site has **not** been patched. This is an offline export refinement of the same performance: only the first two thumb joints use a more natural opposition path; original distal thumb contact transforms, keys, music and cameras remain unchanged.

| Half-open frame interval | Timeline | Frames |
|---|---:|---:|
| `[672,960)` | 28–40s | 288 |
| `[1824,2112)` | 76–88s | 288 |
| `[2496,3024)` | 104–126s | 528 |
| `[3648,3936)` | 152–164s | 288 |

The other4,105 video frames retain their original H.264 packet payloads when the verified packet-splice method succeeds. The full AAC soundtrack remains copied from the original master. Correction rendering/splicing is still running at this archive snapshot; final reports will be appended separately. The existing social excerpt lies outside these correction ranges.

`daybreak-wedge-qa/contact-preserving/` includes only the accepted correction, its source patch, recorded approval/ranges and pose audit. Rejected prototypes, copied compiled Site modules and asset binaries are excluded. The audit covers1,392 poses and993 held-thumb mesh contacts, with gaps−1.023 to−0.068mm and no missing contacts. Inspect the free transitions listed in `AUDIT-HANDOFF.md` in encoded footage. These measurements are not claims of critical listening or browser verification.

### Rebuild the exact isolated correction

First complete the base setup/compilation above. Keep the original Site and base compiled modules unchanged. Extract the corrected tools into the original RAM directory layout; the archived renderer and pose server deliberately retain those absolute paths. These commands are for a fresh separate rebuild, never an active export directory:

```bash
unzip Daybreak-export-source.zip 'daybreak-wedge-qa/*' -d /dev/shm
export DAYBREAK_CORRECTED_ROOT=/dev/shm/daybreak-wedge-qa/contact-preserving
mkdir -p "$DAYBREAK_CORRECTED_ROOT/compiled"
mkdir -p "$DAYBREAK_CORRECTED_ROOT/build-src/app/performance"
ln -s /workspace/sites/daybreak-performance/node_modules "$DAYBREAK_CORRECTED_ROOT/node_modules"
ln -s /workspace/sites/daybreak-performance/public "$DAYBREAK_CORRECTED_ROOT/public"
ln -s /workspace/scratch/daybreak-video/egl-libs "$DAYBREAK_CORRECTED_ROOT/egl-libs"
cp /workspace/sites/daybreak-performance/app/performance/pianist.ts "$DAYBREAK_CORRECTED_ROOT/build-src/app/performance/pianist.ts"
patch -d "$DAYBREAK_CORRECTED_ROOT/build-src" -p0 < "$DAYBREAK_CORRECTED_ROOT/pianist.patch"
for component in direction math piano stage; do
  cp "/workspace/scratch/daybreak-video/compiled/$component.mjs" "$DAYBREAK_CORRECTED_ROOT/compiled/$component.mjs"
done
/workspace/scratch/daybreak-export-env/bin/python "$DAYBREAK_CORRECTED_ROOT/rebuild-approved-compiled.py" /workspace/scratch/daybreak-video/compiled/pianist.mjs "$DAYBREAK_CORRECTED_ROOT/compiled/pianist.mjs"
```

The TypeScript patch is the readable source-level change. The accepted prototype was originally edited after TypeScript transpilation, so a normal re-transpile of the patched TypeScript can have different formatting/bytes. `rebuild-approved-compiled.py` replays only the small accepted delta onto the verified base compile and asserts the exact approved output hash. It refuses an existing output or mismatched base. It does not include the full compiled Site source. The remaining four modules are generated by the base compile. No public Site files are changed by this workflow.

The root-level archive contains the updated correction/splice scripts under `daybreak-video/`; extract that folder to `/workspace/scratch` along with the base tooling. Both scripts default to preparation-only mode. The recorded source approval is for the archived accepted hashes only. Execute the accepted four ranges and splice into a **new** output directory:

```bash
cd /workspace/scratch/daybreak-video
ln -s /dev/shm/daybreak-film-rebuild film-1080p
export LD_LIBRARY_PATH=/workspace/scratch/daybreak-video/egl-libs/root/usr/lib/x86_64-linux-gnu
export __EGL_VENDOR_LIBRARY_FILENAMES=/workspace/scratch/daybreak-video/egl-libs/root/usr/share/glvnd/egl_vendor.d/50_mesa.json
/workspace/scratch/daybreak-export-env/bin/python render-approved-corrections.py --module "$DAYBREAK_CORRECTED_ROOT/render.py" --source-root "$DAYBREAK_CORRECTED_ROOT" --approval "$DAYBREAK_CORRECTED_ROOT/render-approval.json" --ranges "$DAYBREAK_CORRECTED_ROOT/approved-ranges.json" --out /dev/shm/daybreak-corrections-rebuild --execute
/workspace/scratch/daybreak-export-env/bin/python splice-corrected-ranges.py --base /dev/shm/daybreak-film-rebuild --patches /dev/shm/daybreak-corrections-rebuild/approved-patches.json --ranges "$DAYBREAK_CORRECTED_ROOT/approved-ranges.json" --output /dev/shm/daybreak-corrected-rebuild --execute
```

The correction script also reads `/workspace/scratch/daybreak-video/film-1080p/manifest.json` to validate the base GOP boundaries. For a fresh rebuild, make `film-1080p` a symlink to the completed base output `/dev/shm/daybreak-film-rebuild` before running it. Do not replace a live or existing correct path. A runtime-generated EGL vendor JSON may have distribution-specific bytes; its hash is recorded in each render plan. The accepted compiled/core source hashes must match.

The splice script checks all5,497 encoded packet hashes, decoded frame hashes and dense timestamps. It never overwrites the base movie or handles audio. If the packet-copy gate fails, use the explicitly documented fallback in `CORRECTION-SPLICE.md`; do not claim packet preservation after a reencode.

### Package the corrected movie with unchanged AAC

`finish-export.py` expects a folder with `completion.json` and `daybreak-video-only.mp4`. Point a fresh adapter folder at the verified corrected movie so its established attribution/mux code packages the correct video:

```bash
mkdir -p /dev/shm/daybreak-corrected-package-rebuild
ln -s /dev/shm/daybreak-corrected-rebuild/daybreak-corrected-video-only.mp4 /dev/shm/daybreak-corrected-package-rebuild/daybreak-video-only.mp4
python3 - <<'JSON_SETUP'
import json
from pathlib import Path
root=Path('/dev/shm/daybreak-corrected-rebuild')
report=json.loads((root/'splice-verification.json').read_text())
assert report['passed'] and report['presentation_frames']==5497
Path('/dev/shm/daybreak-corrected-package-rebuild/completion.json').write_text(json.dumps({'complete':True,'frames':5497,'splice_verification':str(root/'splice-verification.json')}))
JSON_SETUP
/workspace/scratch/daybreak-export-env/bin/python /workspace/scratch/daybreak-video/finish-export.py /dev/shm/daybreak-corrected-package-rebuild /dev/shm/daybreak-final-rebuild
/workspace/scratch/daybreak-export-env/bin/python /workspace/scratch/daybreak-video/verify-export.py /dev/shm/daybreak-final-rebuild/Daybreak-full-desktop.mp4
```

Confirm `aac_packets_identical_to_master` is true in final QA. The adapter's completion file identifies verified splice completion; it does not claim a new full base render. Save the final movie and reports to persistent storage because `/dev/shm` is temporary.

### Accepted correction hashes

```text
10c5444f617f0b1414fb1c61c07a75cf4f9fc9ad287995aebeec4ddeaa4b365c  render.py
179c9fc0fc8c87250caa98aab6f840db79f17ac0b3c3cf757573705d985b71b3  pose-server.mjs
841ae55c66e98ac9ab2aeb678fd0548ddb2a54de1e2dbd1032e1948323e2dc35  compiled/pianist.mjs
2e1a364c6318f4d1211550b2ba5580c1e08d9b8babb171c9b9d84392822cfe1f  pianist.patch
c5295408ee63f1dcbb3b35051e72cf492893b231c2aebbb9f5c3fa3107f4c3d0  approved-ranges.json
3fa9739f48a445242716a8a7b217aaf7d1dce3547a4215005f84df0f44fb22cf  render-approval.json
```

The compiled pianist hash is recorded although that full module is deliberately excluded. `rebuild-approved-compiled.py` recreates it byte-for-byte from the original compiled module. Additional archive tools/audits have a manifest in `ARCHIVE-SHA256.txt`.

## Frozen tool hashes

The8 original tool/document files are preserved byte-for-byte:

```text
3854371e43c542a5061a864d6ff134e5662e88d7296ea1e1273b9441cdda49a6  daybreak-video-gl/render.py
8b3574bd03948e1ac940ffeb76e9a140229635b422c109f261f6d758eb42d27e  daybreak-video-gl/RENDER-NOTES.md
a7928b6c4b3bf24bc38351ff687278445d409038dc2695019610e09967a92b69  daybreak-video/pose-server.mjs
a12de61721a5cb1c570bff649bca2a0d609f953046eec4a3799ce68250046a60  daybreak-video/compile.cjs
7c3879b3c840912d76ebf12f20c9f1ce3f63e1217c8391e21a42e75e7d748cf8  daybreak-video/render-film.py
ca698ebab7d042122534e44b019b72fde9cfb4ae486b57035b4e12874f5fa848  daybreak-video/film_encoder.py
8a7660097fc640c349fd0f198545cb68621a38c9ffa51dd5150e352233100137  daybreak-video/finish-export.py
3a192f1530a5d7dd3e11d6595777b2bb4a7983349c3b644f91ca4e518f5e3f29  daybreak-video/verify-export.py
```

## External source hashes used by the film harness

The following external dependencies are deliberately excluded from this archive. Recompiling the same Site sources with its recorded TypeScript version should reproduce the compiled-module bytes; compare them before expecting the same animation.

```text
6fa7890fb94d4b63b0445983e794f03383544c3694506c82245eecccd7df3e4f  /workspace/scratch/daybreak-video/compiled/direction.mjs
152c574ece9d1c45875c0cecc35cba9295c717947f3098ca0df510ec8d7b61cf  /workspace/scratch/daybreak-video/compiled/math.mjs
541e78c6ff367979c5fc35c2f4b43ed455b1165df40708acbfba349a16fc4971  /workspace/scratch/daybreak-video/compiled/pianist.mjs
6a70b44ad1de2e7b8bb19a42a288b78403ff3e4bf65d058c24b4ea846863a6cf  /workspace/scratch/daybreak-video/compiled/piano.mjs
86ee5187190d71adcdff13d569776c737ad585f527ca3a36892fdbd7ec5b41f1  /workspace/scratch/daybreak-video/compiled/stage.mjs
0587348ddda6c2fb7c415148ffca11c09c64e844069b0d4426fc6dff89d24f84  /workspace/scratch/daybreak-video/public/assets/score.json
48aa8727f23d2102ec83b6e0ce44baaeb05f3f89c106b656b2094c37cc70f014  /workspace/scratch/daybreak-video/public/assets/pianist.glb
```

## Completed delivery verification

The delivered `Daybreak-full-desktop.mp4` contains all 5,497 frames at 1920×1080 and 24 fps. Its final audio/video decode passed. The mastered AAC packets are unchanged, and decoded audio had zero measured lag against the lossless WAV at 0, 57.55, 163.15 and 221 seconds. Actual reports and sampled visual evidence are under `qa/`. These checks do not claim continuous watching, listening, or a literal browser recording.

Final MP4 SHA256: `549b14ab97e4e76d26bfd9cdd0b10b97cf0fd2bbdf4a28dd1a288a38f26f6e7b`.

A separate `Daybreak-soundtrack.wav` was delivered as the lossless master. Restore it as `daybreak-master.wav` at the path expected by the scripts. To recover the mastered AAC packets from the delivered full film, use `ffmpeg -i Daybreak-full-desktop.mp4 -vn -c:a copy daybreak-master.m4a`; this remux can have different container bytes while preserving the audio packets. Keep the accompanying sample credits when sharing or editing.
